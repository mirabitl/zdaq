// Report 0MQ version in Node.js

var zmq = require('zeromq');

console.log("Current 0MQ version is " + zmq.version);
