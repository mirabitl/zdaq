//
//  Weather update client in C++
//  Connects SUB socket to tcp://localhost:5556
//  Collects weather updates and finds avg temp in zipcode
//
//  Olivier Chamoux <olivier.chamoux@fr.thalesgroup.com>
//
#include <zmq.hpp>
#include <iostream>
#include <sstream>
#include <stdio.h>
#include <dirent.h>
#include <string>
#include <string.h>
#include <unistd.h>
#include "zhelpers.hpp"
#include <regex>
int dsfilter(const struct dirent *dir)
// post: returns 1/true if name of dir ends in .mp3 
{
const char *s = dir->d_name;
 std::regex txt_regex("DS-.*+\\.ipc");
 std::string fname( dir->d_name);
 return (std::regex_match(fname, txt_regex));
 
 //return 0;
}

class zmRouter
{
public:
  zmRouter( zmq::context_t* c) : _context(c),_publisher(NULL)
  {
    _socks.clear();
    memset(_items,0,255*sizeof(zmq_pollitem_t));
  }
  void list()
  {
    struct dirent **eps;
    int n;
    
    n = scandir ("/dev/shm", &eps, dsfilter, alphasort);
    if (n >= 0)
      {
	int cnt;
	for (cnt = 0; cnt < n; ++cnt)
	  {
	    std::stringstream ss;
	    ss<<"ipc:///dev/shm/"<<eps[cnt]->d_name;
	    std::cout<<ss.str()<<std::endl;
	    this->addInputStream(ss.str());
	  }
      }
    else
      perror ("Couldn't open the directory");

    
  }
  void addInputStream(std::string fn)
  {
    zmq::socket_t *subscriber=new zmq::socket_t((*_context),ZMQ_SUB);
    subscriber->setsockopt(ZMQ_SUBSCRIBE, "", 0);
    subscriber->connect(fn);
    int idx=_socks.size();
    _items[idx].socket =(*subscriber);
    _items[idx].events=ZMQ_POLLIN;
    _socks.push_back(subscriber);
  }
  void addOutputStream(std::string fn)
  {
    if (_publisher==NULL)
      {
	_publisher=new zmq::socket_t((*_context),ZMQ_PUB);
      }
    _publisher->bind(fn);
    
  }

  void start() {_running=true;}
  void stop() {_running=false;}
  void poll()
  {
    zmq::message_t message;
    while (_running)
      {
	int rc = zmq::poll(_items, _socks.size(), -1);
	for (int i=0;i<_socks.size();i++)
	  {
	    if (_items [i].revents & ZMQ_POLLIN)
	      {
		std::string identity = s_recv((*_socks[i]));

		_socks[i]->recv(&message);
		printf("Socket %d ID %s  size %d \n",i,identity.c_str(),message.size());
		if (_publisher)
		  {
		    s_sendmore((*_publisher),identity);
		    _publisher->send(message);
		    std::cout<<"Forwarding\n";
		  }
	      }
	  }
	::usleep(1);
      }
  }

private:
  std::vector<zmq::socket_t*> _socks;
  zmq_pollitem_t _items[255];
  zmq::context_t* _context;
  zmq::socket_t* _publisher;
  bool _running;
};




int main (int argc, char *argv[])
{
    zmq::context_t context (1);
    zmRouter r(&context);
    r.list();
    r.addOutputStream("tcp://*:5556");
    r.start();
    r.poll();
    /**
    //  Socket to talk to server
    std::cout << "Collecting updates from weather server...\n" << std::endl;
    zmq::socket_t subscriber (context, ZMQ_SUB);
    subscriber.connect("tcp://localhost:5556");

    //  Subscribe to zipcode, default is NYC, 10001
	const char *filter = (argc > 1)? argv [1]: "10001 ";
    subscriber.setsockopt(ZMQ_SUBSCRIBE, filter, strlen (filter));
    printf("Message collection \n");

    //  Process 100 updates
    int update_nbr;
    long total_temp = 0;
    for (update_nbr = 0; update_nbr < 10000; update_nbr++) {

        zmq::message_t update;
        int zipcode, temperature, relhumidity;

        subscriber.recv(&update);

        std::istringstream iss(static_cast<char*>(update.data()));
	iss >> zipcode >> temperature >> relhumidity ;

	printf("%s \n",(char*) update.data());
	total_temp += temperature;
    }
    std::cout 	<< "Average temperature for zipcode '"<< filter
    			<<"' was "<<(int) (total_temp / update_nbr) <<"F"
    			<< std::endl;
    return 0;
    **/
    return 0;
}
