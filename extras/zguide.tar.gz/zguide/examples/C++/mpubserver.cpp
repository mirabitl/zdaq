//
//  Weather update server in C++
//  Binds PUB socket to tcp://*:5556
//  Publishes random weather updates
//
//  Olivier Chamoux <olivier.chamoux@fr.thalesgroup.com>
//
#include <zmq.hpp>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <sstream>
#include <iostream>
#include "buffer.hh"
//#if (defined (WIN32))
#include <zhelpers.hpp>
//#endif

//#define within(num) (int) ((float) num * random () / (RAND_MAX + 1.0))
#include <unistd.h>

class zmPublisher
{
public:
  zmPublisher( zmq::context_t* c, uint32_t det,uint32_t dif) : _detId(det),_sourceId(dif), _context(c)
  {
    std::stringstream sheader;
    sheader<<"DS-"<<det<<"-"<<dif;
    _header=sheader.str();
    _publisher= new zmq::socket_t((*_context), ZMQ_PUB);
    sheader.str(std::string());
    sheader<<"ipc://"<<"/dev/shm/DS-"<<det<<"-"<<dif<<".ipc";
    _publisher->bind(sheader.str());
    _buffer=new levbdim::buffer(512*1024);
    _buffer->setDetectorId(det);
    _buffer->setDataSourceId(dif);
  }
  void publish(uint64_t bx, uint32_t gtc,char* data,uint32_t len)
  {
    std::stringstream ss;
    ss<<_header<<" "<<gtc<<" "<<bx;
    s_sendmore((*_publisher),ss.str());
    _buffer->setBxId(bx);
    _buffer->setEventId(gtc);
    _buffer->setPayload((void*) data,len);
    //_buffer->setPayloadSize(len);
    
    zmq::message_t message(_buffer->size());
    memcpy(message.data(),_buffer->ptr(),_buffer->size());
    _publisher->send(message);
  }
private:
  zmq::context_t* _context;
  uint32_t _detId,_sourceId;
  zmq::socket_t *_publisher;
  std::string _header;
  levbdim::buffer* _buffer;
};

int main () {

    //  Prepare our context and publisher
    zmq::context_t context (1);
    //zmq::socket_t publisher (context, ZMQ_PUB);
    //publisher.bind("tcp://*:5556");
    //publisher.bind("ipc:///tmp/weather1.ipc");				// Not usable on Windows.

    //  Initialize random number generator
    srandom ((unsigned) time (NULL));
    std::vector<zmPublisher*> vpub;
    for (int idif=12;idif<25;idif++)
      {
	zmPublisher* zp=new zmPublisher(&context,110,idif);
	vpub.push_back(zp);
      }
    uint32_t evt=0;
    uint64_t bx;
    char cda[512*1024];
    uint32_t *ida=(uint32_t*) cda;
    while (1)
      {

	for (auto x:vpub)
	  {
	    uint32_t len=within(65500);
	    bx=time(0)*within(1000);
	    ida[0]=len;
	    x->publish(bx,evt,cda,len);
	    std::cout<<"publishing "<<evt<<"\n";
	  }
	::usleep(100000);
	evt++;
        // int zipcode, temperature, relhumidity;
	
        // //  Get values that will fool the boss
	// int idet=110;
	// for (int idif=12;idif<25;idif++)
	//   {
	//     std::stringstream sheader;
	//     sheader<<"DS-"<<idet<<"-"<<idif;
	//     s_sendmore(publisher,sheader.str());
	//     zipcode     = within (100000);
	//     temperature = within (215) - 80;
	//     relhumidity = within (50) + 10;
	    
	//     //  Send message to all subscribers
	//     zmq::message_t message(within(65500));
	//     snprintf ((char *) message.data(), 20 ,
	// 	      "%05d %d %d", zipcode, temperature, relhumidity);
	//     //printf("Message is %s \n",(char *) message.data());
	//     publisher.send(message);
	//  }
      }
	//::usleep(100000);


    return 0;
}
