
ØMQ - Python examples
=====================

See LICENSE in examples directory

Before committing changes or additions to the Python examples,
please run them through reindent.py. This minimizes diffs on
non-significant whitespace.

        python -m reindent --nobackup *.py

reindent.py is in the Tools/scripts directory of a python tar
distribution or can be installed from 
[PyPi](http://pypi.python.org/pypi/Reindent/0.1.0)
using pip or easy_install:

        pip install reindent

